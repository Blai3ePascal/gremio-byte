#include <stdio.h>

int main(void) {
    int puntos = 0;
    int *p = &puntos;
    /* Completa esta función: Lee el valor inicial y suma tres a través de *p. */
    /* Debe funcionar con 7, 0 y 20. */
    return 0;
}
