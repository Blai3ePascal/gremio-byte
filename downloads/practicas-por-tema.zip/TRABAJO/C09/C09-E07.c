#include <stdio.h>

int main(void) {
    int a = 2, b = 8;
    int *p = &a;
    /* Completa aquí: Resuelve el paso pendiente de El puntero puede cambiar de */
    /* destino. Consulta los datos y requisitos del encargo. */
    printf("%d %d\n", a, b);
    return 0;
}
