#include <stdio.h>

int main(void) {
    int a = 2, b = 8;
    int *p = &a;
    /* Completa esta función: Mantén p apuntando a a y aumenta el valor apuntado */
    /* en uno. */
    return 0;
}
