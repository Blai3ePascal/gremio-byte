#include <stdio.h>

int main(void) {
    int puntos = 7;
    int *p = NULL;
    *p = 10;
    printf("%d %d\n", puntos, *p);
    return 0;
}
