/* Investiga el fallo: Una escritura indirecta. Lee el encargo antes de ejecutar. */
#include <stdio.h>

int main(void) {
    int puntos = 7;
    int *p = NULL;
    *p = 10;
    printf("%d %d\n", puntos, *p);
    return 0;
}
