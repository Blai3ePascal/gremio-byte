#include <stdio.h>

int main(void) {
    int puntos = 7;
    TODO *p = 10;
    printf("%d %d\n", puntos, *p);
    return 0;
}
