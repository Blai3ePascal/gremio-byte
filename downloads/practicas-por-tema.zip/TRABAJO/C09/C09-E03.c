#include <stdio.h>

int main(void) {
    int puntos = 7;
    /* Completa aquí: Resuelve el paso pendiente de Una escritura indirecta. */
    /* Consulta los datos y requisitos del encargo. */
    printf("%d %d\n", puntos, *p);
    return 0;
}
