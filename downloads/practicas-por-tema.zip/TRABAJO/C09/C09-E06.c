/* Investiga el fallo: El puntero puede cambiar de destino. Lee el encargo antes */
/* de ejecutar. */
#include <stdio.h>

int main(void) {
    int a = 2, b = 8;
    int *p = &a;
    p = &a;
    *p = 9;
    printf("%d %d\n", a, b);
    return 0;
}
