void premiar(int *puntos) {
    /* Escribe la actualización usando el destino. */
}
