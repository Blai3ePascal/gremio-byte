void premiar(int *puntos) {
    /* Completa esta función: Actualiza el entero del llamador sumándole 3 a */
    /* través de un puntero válido. No basta con cambiar una copia local. */
    /* Comprueba NULL antes de escribir para conservar el contrato de la función. */
}
