Actualiza el entero del llamador sumándole 3 a través de un puntero válido. No basta con cambiar una copia local. Comprueba NULL antes de escribir para conservar el contrato de la función.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Marcador inicial | `0` | `3` |
| Marcador existente | `7` | `10` |
| Otra ficha | `14` | `17` |