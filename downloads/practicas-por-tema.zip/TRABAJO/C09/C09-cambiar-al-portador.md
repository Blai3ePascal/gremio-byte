### El encargo

Una herramienta puede apuntar a distintos objetos. Observa cuál cambia realmente.

Actualiza el entero del llamador sumándole 3 a través de un puntero válido. No basta con cambiar una copia local. Comprueba NULL antes de escribir para conservar el contrato de la función.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Marcador inicial | `0` | `3` |
| Marcador existente | `7` | `10` |
| Otra ficha | `14` | `17` |

### Requisitos de aprendizaje

- Acceder al objeto a través de un puntero o parámetro de array; declararlo sin utilizarlo no basta.

### Contrato de la función

Conserva la firma proporcionada. El juego enlaza un programa de prueba que llama a tu función. Devuelve o modifica los datos según el encargo; no sustituyas ese efecto por un mensaje.

- {"stdin": "0", "expected": "3\n", "label": "Marcador inicial"}
- {"stdin": "7", "expected": "10\n", "label": "Marcador existente"}
- {"stdin": "14", "expected": "17\n", "label": "Otra ficha"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.
