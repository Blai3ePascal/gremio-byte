#include <stdio.h>

int main(void) {
    /* Completa esta función: Muestra Sala 8 y después Abierta, en dos líneas. */
    return 0;
}
