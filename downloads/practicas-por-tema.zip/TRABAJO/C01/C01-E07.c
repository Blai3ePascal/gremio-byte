#include <stdio.h>

int main(void) {
    /* Completa aquí: Resuelve el paso pendiente de El salto de línea pertenece */
    /* al texto. Consulta los datos y requisitos del encargo. */
    printf("Lista\n");
    return 0;
}
