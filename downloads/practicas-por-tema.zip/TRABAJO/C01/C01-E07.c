#include <stdio.h>

int main(void) {
    TODO printf("4\n");
    printf("Lista\n");
    return 0;
}
