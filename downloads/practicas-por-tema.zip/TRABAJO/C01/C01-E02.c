/* Investiga el fallo: Dos llamadas y dos líneas. Lee el encargo antes de */
/* ejecutar. */
#include <stdio.h>

int main(void) {
    printf("Equipo azul\n");
    printf("Puntos: %d\n", 2 - 3);
    return 0;
}
