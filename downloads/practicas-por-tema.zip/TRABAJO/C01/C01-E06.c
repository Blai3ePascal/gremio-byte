#include <stdio.h>

int main(void) {
    printf("Sala\n");
    printf("4\n");
    printf("Lista\n");
    return 0;
}
