/* Investiga el fallo: El salto de línea pertenece al texto. Lee el encargo antes */
/* de ejecutar. */
#include <stdio.h>

int main(void) {
    printf("Sala\n");
    printf("4\n");
    printf("Lista\n");
    return 0;
}
