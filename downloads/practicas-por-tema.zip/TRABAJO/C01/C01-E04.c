#include <stdio.h>

int main(void) {
    /* Completa esta función: Presenta Equipo verde y la suma 4 + 6. */
    return 0;
}
