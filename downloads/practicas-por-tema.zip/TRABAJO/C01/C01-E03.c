#include <stdio.h>

int main(void) {
    printf("Equipo azul\n");
    printf("Puntos: %d\n", TODO);
    return 0;
}
