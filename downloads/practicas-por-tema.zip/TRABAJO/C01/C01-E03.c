#include <stdio.h>

int main(void) {
    printf("Equipo azul\n");
    /* Completa aquí: Resuelve el paso pendiente de Dos llamadas y dos líneas. */
    /* Consulta los datos y requisitos del encargo. */
    return 0;
}
