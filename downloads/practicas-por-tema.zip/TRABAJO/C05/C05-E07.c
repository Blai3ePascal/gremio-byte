#include <stdio.h>

int main(void) {
    int turnos = 3;
    while (turnos > 0) {
        printf("%d\n", turnos);
        /* Completa aquí: Resuelve el paso pendiente de Una condición antes de */
        /* repetir. Consulta los datos y requisitos del encargo. */
    }
    return 0;
}
