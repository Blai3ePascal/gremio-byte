#include <stdio.h>

int main(void) {
    int turnos = 3;
    while (turnos > 0) {
        printf("%d\n", turnos);
        TODO
    }
    return 0;
}
