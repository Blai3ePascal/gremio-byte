#include <stdio.h>

int main(void) {
    int total = 0;
    for (int i = 1; i <= 3; i++) {
        /* Completa aquí: Resuelve el paso pendiente de Acumulación con for. */
        /* Consulta los datos y requisitos del encargo. */
    }
    printf("%d\n", total);
    return 0;
}
