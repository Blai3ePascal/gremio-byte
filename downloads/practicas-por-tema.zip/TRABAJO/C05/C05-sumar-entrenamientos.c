int entrenar(int n) {
    /* Completa esta función: Calcula 1 + 2 + ... + n usando un bucle. n es un */
    /* entero entre 0 y 100. Un contador avanza y un acumulador conserva el */
    /* total. */
}
