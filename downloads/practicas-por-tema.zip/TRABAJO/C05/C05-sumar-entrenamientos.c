int entrenar(int n) {
    /* Escribe el cálculo o la actualización. */
    return 0;
}
