/* Investiga el fallo: Acumulación con for. Lee el encargo antes de ejecutar. */
#include <stdio.h>

int main(void) {
    int total = 0;
    for (int i = 1; i <= 3; i++) {
        total = i;
    }
    printf("%d\n", total);
    return 0;
}
