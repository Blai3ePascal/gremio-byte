/* Investiga el fallo: Una condición antes de repetir. Lee el encargo antes de */
/* ejecutar. */
#include <stdio.h>

int main(void) {
    int turnos = 3;
    while (turnos > 0) {
        printf("%d\n", turnos);
        turnos++;
    }
    return 0;
}
