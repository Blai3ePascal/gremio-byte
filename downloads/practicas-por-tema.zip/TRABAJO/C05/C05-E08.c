#include <stdio.h>

int main(void) {
    int turnos = 3;
    /* Completa esta función: Repite con turnos=0 y explica por qué no aparece */
    /* ninguna línea. */
    return 0;
}
