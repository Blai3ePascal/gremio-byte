Calcula 1 + 2 + ... + n usando un bucle. n es un entero entre 0 y 100. Un contador avanza y un acumulador conserva el total.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Cero sesiones | `0` | `0` |
| Tres sesiones | `3` | `6` |
| Siete sesiones | `7` | `28` |