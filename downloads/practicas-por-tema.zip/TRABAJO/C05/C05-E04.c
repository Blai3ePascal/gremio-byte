#include <stdio.h>

int main(void) {
    int total = 0;
    /* Completa esta función: Suma del 1 al 5 sin copiar instrucciones de */
    /* acumulación. */
    return 0;
}
