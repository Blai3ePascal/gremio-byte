#include <stdio.h>

int main(void) {
    unsigned int permiso = 4;
    /* Completa esta función: Prueba permiso=6 y compara las dos máscaras. */
    return 0;
}
