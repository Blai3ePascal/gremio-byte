#include <stdio.h>

int main(void) {
    unsigned int permiso = 4;
    printf("%u\n", permiso >> 1);
    /* Completa aquí: Resuelve el paso pendiente de Desplazamiento y máscara. */
    /* Consulta los datos y requisitos del encargo. */
    printf("%u\n", permiso & 2u);
    return 0;
}
