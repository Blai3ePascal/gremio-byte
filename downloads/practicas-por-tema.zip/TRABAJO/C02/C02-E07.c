#include <stdio.h>

int main(void) {
    unsigned int permiso = 4;
    printf("%u\n", permiso >> 1);
    printf("%u\n", TODO);
    printf("%u\n", permiso & 2u);
    return 0;
}
