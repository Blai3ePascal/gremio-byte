#include <stdio.h>

int main(void) {
    unsigned int a = 5, b = 3;
    /* Completa esta función: Usa a=6 y b=3 para distinguir también las dos */
    /* primeras salidas. */
    return 0;
}
