#include <stdio.h>

int main(void) {
    unsigned int a = 5, b = 3;
    printf("%u\n", a & b);
    printf("%d\n", a && b);
    /* Completa aquí: Resuelve el paso pendiente de Lógico y bit a bit. Consulta */
    /* los datos y requisitos del encargo. */
    return 0;
}
