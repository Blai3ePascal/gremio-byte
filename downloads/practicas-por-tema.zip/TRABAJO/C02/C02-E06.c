/* Investiga el fallo: Desplazamiento y máscara. Lee el encargo antes de */
/* ejecutar. */
#include <stdio.h>

int main(void) {
    unsigned int permiso = 4;
    printf("%u\n", permiso >> 1);
    printf("%u\n", permiso & 2u);
    printf("%u\n", permiso & 2u);
    return 0;
}
