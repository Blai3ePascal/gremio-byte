#include <stdio.h>
void cambiar(int *a, int *b) {
    int temporal = *a;
    /* Completa esta función: Intercambia -3 y 4. */
}
int main(void) {
    int x = 2, y = 9;
    /* Completa esta función: Intercambia -3 y 4. */
    return 0;
}
