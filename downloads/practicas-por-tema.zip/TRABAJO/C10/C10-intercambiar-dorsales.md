Intercambia ambos enteros mediante los punteros recibidos. Conserva el valor inicial que necesitas antes de sobrescribirlo.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Dos dorsales | `2 9` | `9 2` |
| Incluye cero | `0 5` | `5 0` |
| Valores iguales | `4 4` | `4 4` |