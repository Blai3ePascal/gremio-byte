#include <stdio.h>
int sumar(const int datos[], int n) {
    int total = 0;
    /* Completa esta función: Comprueba sumar(datos, 0) y sumar(datos, 1). */
}
int main(void) {
    int datos[] = {2, 4, 6};
    /* Completa esta función: Comprueba sumar(datos, 0) y sumar(datos, 1). */
    return 0;
}
