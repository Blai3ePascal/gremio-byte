void cambiar(int *a, int *b) {
    /* Completa esta función: Intercambia ambos enteros mediante los punteros */
    /* recibidos. Conserva el valor inicial que necesitas antes de */
    /* sobrescribirlo. */
}
