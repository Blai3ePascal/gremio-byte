void cambiar(int *a, int *b) {
    /* Escribe la actualización usando el destino. */
}
