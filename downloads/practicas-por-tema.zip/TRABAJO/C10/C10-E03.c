#include <stdio.h>
void cambiar(int *a, int *b) {
    int temporal = *a;
    *a = *b;
    /* Completa aquí: Resuelve el paso pendiente de Intercambiar necesita una */
    /* copia temporal. Consulta los datos y requisitos del encargo. */
}
int main(void) {
    int x = 2, y = 9;
    cambiar(&x, &y);
    printf("%d %d\n", x, y);
    return 0;
}
