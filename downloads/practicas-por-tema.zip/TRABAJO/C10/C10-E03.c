#include <stdio.h>
void cambiar(int *a, int *b) {
    int temporal = *a;
    *a = *b;
    TODO
}
int main(void) {
    int x = 2, y = 9;
    cambiar(&x, &y);
    printf("%d %d\n", x, y);
    return 0;
}
