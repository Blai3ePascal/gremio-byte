/* Investiga el fallo: Intercambiar necesita una copia temporal. Lee el encargo */
/* antes de ejecutar. */
#include <stdio.h>
void cambiar(int *a, int *b) {
    int temporal = *a;
    *a = *b;
    *b = *a;
}
int main(void) {
    int x = 2, y = 9;
    cambiar(&x, &y);
    printf("%d %d\n", x, y);
    return 0;
}
