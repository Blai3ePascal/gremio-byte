#include <stdio.h>
int sumar(const int datos[], int n) {
    int total = 0;
    for (int i = 0; i < n; i++)
        total += datos[i];
    return total;
}
int main(void) {
    int datos[] = {2, 4, 6};
    printf("%d\n", TODO);
    return 0;
}
