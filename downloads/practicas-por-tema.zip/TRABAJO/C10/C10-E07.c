#include <stdio.h>
int sumar(const int datos[], int n) {
    int total = 0;
    for (int i = 0; i < n; i++)
        total += datos[i];
    return total;
}
int main(void) {
    int datos[] = {2, 4, 6};
    /* Completa aquí: Resuelve el paso pendiente de La longitud viaja con el */
    /* array. Consulta los datos y requisitos del encargo. */
    return 0;
}
