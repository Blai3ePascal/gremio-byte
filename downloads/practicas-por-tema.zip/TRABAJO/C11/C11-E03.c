#include <stdio.h>
struct Equipo {
    int id;
    int puntos;
};
int main(void) {
    struct Equipo azul = {1, 7};
    /* Completa aquí: Resuelve el paso pendiente de Campos de un registro. */
    /* Consulta los datos y requisitos del encargo. */
    printf("%d %d\n", azul.id, azul.puntos);
    return 0;
}
