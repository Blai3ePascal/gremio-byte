#include <stdio.h>
struct Equipo {
    int id;
    int puntos;
};
int main(void) {
    struct Equipo azul = {1, 7};
    TODO;
    printf("%d %d\n", azul.id, azul.puntos);
    return 0;
}
