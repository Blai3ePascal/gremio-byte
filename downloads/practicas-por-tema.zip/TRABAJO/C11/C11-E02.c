/* Investiga el fallo: Campos de un registro. Lee el encargo antes de ejecutar. */
#include <stdio.h>
struct Equipo {
    int id;
    int puntos;
};
int main(void) {
    struct Equipo azul = {1, 7};
    azul.id += 3;
    printf("%d %d\n", azul.id, azul.puntos);
    return 0;
}
