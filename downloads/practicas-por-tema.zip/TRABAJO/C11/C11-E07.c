#include <stdio.h>
struct Equipo {
    int id;
    int puntos;
};
void premiar(struct Equipo *equipo) {
    /* Completa aquí: Resuelve el paso pendiente de La flecha accede a través de */
    /* un puntero. Consulta los datos y requisitos del encargo. */
}
int main(void) {
    struct Equipo azul = {1, 7};
    premiar(&azul);
    printf("%d\n", azul.puntos);
    return 0;
}
