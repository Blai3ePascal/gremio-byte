#include <stdio.h>
struct Equipo {
    int id;
    int puntos;
};
int main(void) {
    struct Equipo azul = {1, 7};
    /* Completa esta función: Crea el equipo id 2 con 4 puntos y añade 5. */
    return 0;
}
