int repetir(int n) {
    /* Completa esta función: Recibe n entre 0 y 20. Devuelve n usando una */
    /* llamada recursiva que reduzca el problema y un caso base n == 0. Esta */
    /* misión practica recursión. */
}
