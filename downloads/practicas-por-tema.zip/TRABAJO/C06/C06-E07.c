#include <stdio.h>
int sumar(int a, int b) {
    return a + b;
}
int main(void) {
    /* Completa aquí: Resuelve el paso pendiente de El resultado debe */
    /* conservarse. Consulta los datos y requisitos del encargo. */
    return 0;
}
