#include <stdio.h>
int sumar(int a, int b) {
    return a + b;
}
int main(void) {
    TODO printf("%d\n", resultado);
    return 0;
}
