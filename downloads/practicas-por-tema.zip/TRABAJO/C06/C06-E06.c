/* Investiga el fallo: El resultado debe conservarse. Lee el encargo antes de */
/* ejecutar. */
#include <stdio.h>
int sumar(int a, int b) {
    return a + b;
}
int main(void) {
    int resultado = 0;
    sumar(3, 5);
    printf("%d\n", resultado);
    return 0;
}
