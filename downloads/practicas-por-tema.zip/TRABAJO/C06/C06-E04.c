#include <stdio.h>
int doble(int valor) {
    /* Completa esta función: Usa puntos=7 y conserva el valor original en la */
    /* segunda salida. */
}
int main(void) {
    int puntos = 4;
    /* Completa esta función: Usa puntos=7 y conserva el valor original en la */
    /* segunda salida. */
    return 0;
}
