int avanzar(int metros) {
    /* Completa esta función: Devuelve el avance actual más 3. El motor usa */
    /* varias entradas y mueve al portador hasta el resultado calculado. */
}
