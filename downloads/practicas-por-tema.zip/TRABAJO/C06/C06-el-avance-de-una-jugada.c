int avanzar(int metros) {
    /* Escribe el cálculo o la actualización. */
    return 0;
}
