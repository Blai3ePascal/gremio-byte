/* Investiga el fallo: El parámetro es una copia. Lee el encargo antes de */
/* ejecutar. */
#include <stdio.h>
int doble(int valor) {
    return valor + 2;
}
int main(void) {
    int puntos = 4;
    printf("%d %d\n", doble(puntos), puntos);
    return 0;
}
