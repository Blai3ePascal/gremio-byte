#include <stdio.h>
int sumar(int a, int b) {
    /* Completa esta función: Calcula sumar(-3, 5) y conserva el mismo reparto de */
    /* responsabilidades. */
}
int main(void) {
    /* Completa esta función: Calcula sumar(-3, 5) y conserva el mismo reparto de */
    /* responsabilidades. */
    return 0;
}
