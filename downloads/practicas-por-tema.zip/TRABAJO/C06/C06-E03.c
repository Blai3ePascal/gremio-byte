#include <stdio.h>
int doble(int valor) {
    /* Completa aquí: Resuelve el paso pendiente de El parámetro es una copia. */
    /* Consulta los datos y requisitos del encargo. */
}
int main(void) {
    int puntos = 4;
    printf("%d %d\n", doble(puntos), puntos);
    return 0;
}
