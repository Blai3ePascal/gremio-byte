#include <stdio.h>
int doble(int valor) {
    TODO
}
int main(void) {
    int puntos = 4;
    printf("%d %d\n", doble(puntos), puntos);
    return 0;
}
