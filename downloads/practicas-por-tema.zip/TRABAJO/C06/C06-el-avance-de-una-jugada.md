### El encargo

El gremio quiere reutilizar sus herramientas: separa cada tarea en una función.

Devuelve el avance actual más 3. El motor usa varias entradas y mueve al portador hasta el resultado calculado.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Sin avance previo | `0` | `3` |
| Avance intermedio | `4` | `7` |
| Otra entrada | `12` | `15` |

### Requisitos de aprendizaje

- Definir y utilizar una función para el cálculo; conserva la firma si se proporciona.

### Contrato de la función

Conserva la firma proporcionada. El juego enlaza un programa de prueba que llama a tu función. Devuelve o modifica los datos según el encargo; no sustituyas ese efecto por un mensaje.

- {"stdin": "0\n", "expected": "3\n", "label": "Sin avance previo"}
- {"stdin": "4\n", "expected": "7\n", "label": "Avance intermedio"}
- {"stdin": "12\n", "expected": "15\n", "label": "Otra entrada"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.
