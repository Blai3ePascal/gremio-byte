Devuelve el avance actual más 3. El motor usa varias entradas y mueve al portador hasta el resultado calculado.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Sin avance previo | `0` | `3` |
| Avance intermedio | `4` | `7` |
| Otra entrada | `12` | `15` |