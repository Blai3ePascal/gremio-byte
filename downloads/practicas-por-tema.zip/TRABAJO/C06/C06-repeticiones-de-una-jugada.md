### El encargo

El gremio quiere reutilizar sus herramientas: separa cada tarea en una función.

Recibe n entre 0 y 20. Devuelve n usando una llamada recursiva que reduzca el problema y un caso base n == 0. Esta misión practica recursión.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Caso base | `0` | `0` |
| Una llamada pendiente | `1` | `1` |
| Seis niveles | `6` | `6` |

### Requisitos de aprendizaje

- Definir y utilizar una función para el cálculo; conserva la firma si se proporciona.
- Resolver mediante recursión y un caso base.

### Contrato de la función

Conserva la firma proporcionada. El juego enlaza un programa de prueba que llama a tu función. Devuelve o modifica los datos según el encargo; no sustituyas ese efecto por un mensaje.

- {"stdin": "0", "expected": "0\n", "label": "Caso base"}
- {"stdin": "1", "expected": "1\n", "label": "Una llamada pendiente"}
- {"stdin": "6", "expected": "6\n", "label": "Seis niveles"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.
