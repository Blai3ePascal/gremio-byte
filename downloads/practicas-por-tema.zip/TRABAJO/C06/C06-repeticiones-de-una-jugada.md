Recibe n entre 0 y 20. Devuelve n usando una llamada recursiva que reduzca el problema y un caso base n == 0. Esta misión practica recursión.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Caso base | `0` | `0` |
| Una llamada pendiente | `1` | `1` |
| Seis niveles | `6` | `6` |