/* Investiga el fallo: La división depende de los operandos. Lee el encargo antes */
/* de ejecutar. */
#include <stdio.h>

int main(void) {
    int suma = 7, cantidad = 2;
    double media = suma / cantidad;
    printf("%.1f\n", media);
    return 0;
}
