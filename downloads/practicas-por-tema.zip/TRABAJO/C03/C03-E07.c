#include <stdio.h>

int main(void) {
    const char *entrada = "18";
    int edad = 0;
    /* Completa aquí: Resuelve el paso pendiente de Interpretar texto con */
    /* comprobación. Consulta los datos y requisitos del encargo. */
        printf("Entrada invalida\n");
        return 1;
    }
    printf("Edad: %d\n", edad);
    return 0;
}
