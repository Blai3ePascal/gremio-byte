#include <stdio.h>

int main(void) {
    const char *entrada = "18";
    int edad = 0;
    if (sscanf(entrada, "%d", &edad) TODO) {
        printf("Entrada invalida\n");
        return 1;
    }
    printf("Edad: %d\n", edad);
    return 0;
}
