#include <stdio.h>

int main(void) {
    int suma = 7, cantidad = 2;
    /* Completa aquí: Resuelve el paso pendiente de La división depende de los */
    /* operandos. Consulta los datos y requisitos del encargo. */
    printf("%.1f\n", media);
    return 0;
}
