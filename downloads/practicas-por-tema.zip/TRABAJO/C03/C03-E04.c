#include <stdio.h>

int main(void) {
    int suma = 7, cantidad = 2;
    /* Completa esta función: Calcula la media de suma=11 y cantidad=4 con dos */
    /* cifras decimales. */
    return 0;
}
