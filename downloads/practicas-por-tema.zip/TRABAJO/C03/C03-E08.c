#include <stdio.h>

int main(void) {
    const char *entrada = "18";
    int edad = 0;
    /* Completa esta función: Usa entrada="abc" y explica por qué el programa */
    /* termina con estado 1. */
    return 0;
}
