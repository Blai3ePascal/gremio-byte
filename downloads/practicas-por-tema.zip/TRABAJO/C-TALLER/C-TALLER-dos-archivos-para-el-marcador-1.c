#include <stdio.h>
#include "motor.h"
int main(void){printf("%d\n",puntos(TODO));return 0;}
