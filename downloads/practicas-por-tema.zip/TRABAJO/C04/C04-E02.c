/* Investiga el fallo: Una frontera en la nota. Lee el encargo antes de ejecutar. */
#include <stdio.h>

int main(void) {
    int nota = 5;
    if (nota > 5) {
        printf("Aprobado\n");
    } else {
        printf("Pendiente\n");
    }
    return 0;
}
