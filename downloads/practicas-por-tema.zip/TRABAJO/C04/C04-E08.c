#include <stdio.h>

int main(void) {
    int opcion = 2;
    /* Completa esta función: Prueba opcion=8 para recorrer default. */
    return 0;
}
