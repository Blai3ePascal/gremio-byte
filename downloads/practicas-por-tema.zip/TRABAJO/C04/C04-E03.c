#include <stdio.h>

int main(void) {
    int nota = 5;
    if (TODO) {
        printf("Aprobado\n");
    } else {
        printf("Pendiente\n");
    }
    return 0;
}
