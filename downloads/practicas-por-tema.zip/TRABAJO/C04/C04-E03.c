#include <stdio.h>

int main(void) {
    int nota = 5;
    /* Completa aquí: Resuelve el paso pendiente de Una frontera en la nota. */
    /* Consulta los datos y requisitos del encargo. */
        printf("Aprobado\n");
    } else {
        printf("Pendiente\n");
    }
    return 0;
}
