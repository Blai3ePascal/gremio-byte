#include <stdio.h>

int main(void) {
    int opcion = 2;
    switch (opcion) {
    case 1:
        printf("Crear\n");
        break;
        /* Completa aquí: Resuelve el paso pendiente de Opciones discretas con */
        /* switch. Consulta los datos y requisitos del encargo. */
    }
    return 0;
}
