#include <stdio.h>

int main(void) {
    int opcion = 2;
    switch (opcion) {
        case 1: printf("Crear\n"); break;
        TODO
        default: printf("Opcion invalida\n");
    }
    return 0;
}
