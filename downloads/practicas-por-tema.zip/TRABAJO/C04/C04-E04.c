#include <stdio.h>

int main(void) {
    int nota = 5;
    /* Completa esta función: Prueba nota=4 y conserva ambas ramas. */
    return 0;
}
