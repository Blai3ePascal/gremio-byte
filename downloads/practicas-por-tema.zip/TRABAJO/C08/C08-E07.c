#include <stdio.h>
#include <string.h>
int main(void) {
    char a[] = "azul";
    char b[] = "azul";
    printf("%d\n", TODO);
    return 0;
}
