#include <stdio.h>
#include <string.h>
int main(void) {
    char a[] = "azul";
    char b[] = "azul";
    /* Completa aquí: Resuelve el paso pendiente de Comparar el contenido. */
    /* Consulta los datos y requisitos del encargo. */
    return 0;
}
