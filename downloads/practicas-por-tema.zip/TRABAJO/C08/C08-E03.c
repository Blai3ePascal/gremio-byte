#include <stdio.h>
#include <string.h>
int main(void) {
    char nombre[8] = "Luna";
    /* Completa aquí: Resuelve el paso pendiente de Longitud y capacidad. */
    /* Consulta los datos y requisitos del encargo. */
    printf("%zu\n", sizeof nombre);
    return 0;
}
