/* Investiga el fallo: Longitud y capacidad. Lee el encargo antes de ejecutar. */
#include <stdio.h>
#include <string.h>
int main(void) {
    char nombre[8] = "Luna";
    printf("%zu\n", sizeof nombre);
    printf("%zu\n", sizeof nombre);
    return 0;
}
