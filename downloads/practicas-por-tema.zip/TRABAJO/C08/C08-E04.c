#include <stdio.h>
#include <string.h>
int main(void) {
    char nombre[8] = "Luna";
    /* Completa esta función: Cambia el contenido a Sol manteniendo la capacidad. */
    return 0;
}
