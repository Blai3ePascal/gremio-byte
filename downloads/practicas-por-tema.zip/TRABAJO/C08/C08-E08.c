#include <stdio.h>
#include <string.h>
int main(void) {
    char a[] = "azul";
    char b[] = "azul";
    /* Completa esta función: Usa b="verde" y comprueba si sigue habiendo */
    /* igualdad. */
    return 0;
}
