#include <stdio.h>

int main(void) {
    int matriz[2][3] = {{1, 2, 3}, {4, 5, 6}};
    /* Completa aquí: Resuelve el paso pendiente de La fila y la columna tienen */
    /* un orden. Consulta los datos y requisitos del encargo. */
    printf("%d\n", matriz[0][1]);
    return 0;
}
