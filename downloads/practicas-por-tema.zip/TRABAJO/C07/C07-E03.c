#include <stdio.h>

int main(void) {
    int datos[] = {4, 7, 2};
    int total = 0;
    /* Completa aquí: Resuelve el paso pendiente de Un recorrido con longitud. */
    /* Consulta los datos y requisitos del encargo. */
        total += datos[i];
    }
    printf("%d\n", total);
    return 0;
}
