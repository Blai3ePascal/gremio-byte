### El encargo

El almacén organiza sus datos por posiciones. Respeta los límites al consultarlos.

Visita cada combinación de fila y columna mediante dos bucles anidados. Devuelve cuántas celdas has visitado. Una multiplicación da el número, pero esta misión practica el recorrido con dos bucles.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Campo rectangular | `2 3` | `6` |
| Sin filas | `0 4` | `0` |
| Otro tamaño | `3 5` | `15` |

### Requisitos de aprendizaje

- Usar dos bucles anidados dentro de la función; ambos deben participar en el cálculo.

### Contrato de la función

Conserva la firma proporcionada. El juego enlaza un programa de prueba que llama a tu función. Devuelve o modifica los datos según el encargo; no sustituyas ese efecto por un mensaje.

- {"stdin": "2 3", "expected": "6\n", "label": "Campo rectangular"}
- {"stdin": "0 4", "expected": "0\n", "label": "Sin filas"}
- {"stdin": "3 5", "expected": "15\n", "label": "Otro tamaño"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.
