Visita cada combinación de fila y columna mediante dos bucles anidados. Devuelve cuántas celdas has visitado. Una multiplicación da el número, pero esta misión practica el recorrido con dos bucles.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Campo rectangular | `2 3` | `6` |
| Sin filas | `0 4` | `0` |
| Otro tamaño | `3 5` | `15` |