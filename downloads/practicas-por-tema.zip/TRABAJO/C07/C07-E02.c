/* Investiga el fallo: Un recorrido con longitud. Lee el encargo antes de */
/* ejecutar. */
#include <stdio.h>

int main(void) {
    int datos[] = {4, 7, 2};
    int total = 0;
    for (int i = 0; i <= 3; i++) {
        total += datos[i];
    }
    printf("%d\n", total);
    return 0;
}
