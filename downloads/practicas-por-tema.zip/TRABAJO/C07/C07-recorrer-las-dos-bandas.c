int visitar(int filas, int columnas) {
    /* Completa esta función: Visita cada combinación de fila y columna mediante */
    /* dos bucles anidados. Devuelve cuántas celdas has visitado. Una */
    /* multiplicación da el número, pero esta misión practica el recorrido con */
    /* dos bucles. */
}
