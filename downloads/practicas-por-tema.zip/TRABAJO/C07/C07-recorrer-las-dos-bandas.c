int visitar(int filas, int columnas) {
    /* Escribe el cálculo o la actualización. */
    return 0;
}
