#include <stdio.h>

int main(void) {
    int datos[] = {4, 7, 2};
    int total = 0;
    /* Completa esta función: Usa cuatro datos {4,7,2,5} y adapta el límite. */
    return 0;
}
