#include <stdio.h>

int main(void) {
    int matriz[2][3] = {{1, 2, 3}, {4, 5, 6}};
    /* Completa esta función: Muestra el primer elemento de cada fila. */
    return 0;
}
