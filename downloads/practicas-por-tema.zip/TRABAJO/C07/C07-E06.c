/* Investiga el fallo: La fila y la columna tienen un orden. Lee el encargo antes */
/* de ejecutar. */
#include <stdio.h>

int main(void) {
    int matriz[2][3] = {{1, 2, 3}, {4, 5, 6}};
    printf("%d\n", matriz[2][1]);
    printf("%d\n", matriz[0][1]);
    return 0;
}
