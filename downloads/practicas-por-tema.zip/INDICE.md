# Biblioteca de cuadernos

Pascal & Sara · Edición 1.3

Abre una versión **Trabajo** para practicar. La versión **Soluciones** es una referencia, no un requisito para empezar.

| Bloque | Trabajo | Propuestas explicadas |
|---|---|---|
| Edición, compilación y primer programa | [C01_Trabajo](C01_Trabajo.ipynb) | [C01_Soluciones](C01_Soluciones.ipynb) |
| Bits, lógica y representación | [C02_Trabajo](C02_Trabajo.ipynb) | [C02_Soluciones](C02_Soluciones.ipynb) |
| Variables, tipos y entrada/salida | [C03_Trabajo](C03_Trabajo.ipynb) | [C03_Soluciones](C03_Soluciones.ipynb) |
| Condicionales y menús | [C04_Trabajo](C04_Trabajo.ipynb) | [C04_Soluciones](C04_Soluciones.ipynb) |
| Bucles, contadores y trazas | [C05_Trabajo](C05_Trabajo.ipynb) | [C05_Soluciones](C05_Soluciones.ipynb) |
| Funciones y organización del programa | [C06_Trabajo](C06_Trabajo.ipynb) | [C06_Soluciones](C06_Soluciones.ipynb) |
| Vectores, matrices e índices | [C07_Trabajo](C07_Trabajo.ipynb) | [C07_Soluciones](C07_Soluciones.ipynb) |
| Cadenas, capacidad y comparación | [C08_Trabajo](C08_Trabajo.ipynb) | [C08_Soluciones](C08_Soluciones.ipynb) |
| Punteros, direcciones y memoria | [C09_Trabajo](C09_Trabajo.ipynb) | [C09_Soluciones](C09_Soluciones.ipynb) |
| Punteros y parámetros de funciones | [C10_Trabajo](C10_Trabajo.ipynb) | [C10_Soluciones](C10_Soluciones.ipynb) |
| Registros con struct | [C11_Trabajo](C11_Trabajo.ipynb) | [C11_Soluciones](C11_Soluciones.ipynb) |
| Ficheros de texto y comprobación de errores | [C12_Trabajo](C12_Trabajo.ipynb) | [C12_Soluciones](C12_Soluciones.ipynb) |
| Persistencia binaria e integración | [C13_Trabajo](C13_Trabajo.ipynb) | [C13_Soluciones](C13_Soluciones.ipynb) |