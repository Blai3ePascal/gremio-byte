# Biblioteca de cuadernos

Pascal & Sara · Edición 1.1

Abre una versión **Trabajo** para practicar. La versión **Soluciones** es una referencia, no un requisito para empezar.

| Bloque | Trabajo | Propuestas explicadas |
|---|---|---|
| El despertar | [INICIO_Trabajo](INICIO_Trabajo.ipynb) | [INICIO_Soluciones](INICIO_Soluciones.ipynb) |
| Edición, compilación y primer programa | [C01_Trabajo](C01_Trabajo.ipynb) | [C01_Soluciones](C01_Soluciones.ipynb) |
| Bits, lógica y representación | [C02_Trabajo](C02_Trabajo.ipynb) | [C02_Soluciones](C02_Soluciones.ipynb) |
| Variables, tipos y entrada/salida | [C03_Trabajo](C03_Trabajo.ipynb) | [C03_Soluciones](C03_Soluciones.ipynb) |
| Condicionales y menús | [C04_Trabajo](C04_Trabajo.ipynb) | [C04_Soluciones](C04_Soluciones.ipynb) |
| Bucles, contadores y trazas | [C05_Trabajo](C05_Trabajo.ipynb) | [C05_Soluciones](C05_Soluciones.ipynb) |
| Funciones y organización del programa | [C06_Trabajo](C06_Trabajo.ipynb) | [C06_Soluciones](C06_Soluciones.ipynb) |
| Vectores, matrices e índices | [C07_Trabajo](C07_Trabajo.ipynb) | [C07_Soluciones](C07_Soluciones.ipynb) |
| Cadenas, capacidad y comparación | [C08_Trabajo](C08_Trabajo.ipynb) | [C08_Soluciones](C08_Soluciones.ipynb) |
| Punteros, direcciones y memoria | [C09_Trabajo](C09_Trabajo.ipynb) | [C09_Soluciones](C09_Soluciones.ipynb) |
| Punteros y parámetros de funciones | [C10_Trabajo](C10_Trabajo.ipynb) | [C10_Soluciones](C10_Soluciones.ipynb) |
| Registros con struct | [C11_Trabajo](C11_Trabajo.ipynb) | [C11_Soluciones](C11_Soluciones.ipynb) |
| Ficheros de texto y comprobación de errores | [C12_Trabajo](C12_Trabajo.ipynb) | [C12_Soluciones](C12_Soluciones.ipynb) |
| Persistencia binaria e integración | [C13_Trabajo](C13_Trabajo.ipynb) | [C13_Soluciones](C13_Soluciones.ipynb) |
| Vectores: longitud, capacidad y memoria propia | [C14_Trabajo](C14_Trabajo.ipynb) | [C14_Soluciones](C14_Soluciones.ipynb) |
| Búsqueda, ordenación y coste del trabajo | [C15_Trabajo](C15_Trabajo.ipynb) | [C15_Soluciones](C15_Soluciones.ipynb) |
| TAD: pilas y colas con contratos | [C16_Trabajo](C16_Trabajo.ipynb) | [C16_Soluciones](C16_Soluciones.ipynb) |
| Lista enlazada: enlaces y propiedad | [C17_Trabajo](C17_Trabajo.ipynb) | [C17_Soluciones](C17_Soluciones.ipynb) |
| Árbol binario de búsqueda e inorden | [C18_Trabajo](C18_Trabajo.ipynb) | [C18_Soluciones](C18_Soluciones.ipynb) |
| Hash: colisiones, rechazo y crecimiento | [C19_Trabajo](C19_Trabajo.ipynb) | [C19_Soluciones](C19_Soluciones.ipynb) |
| Proyecto: registros, consulta y fichero de texto | [C20_Trabajo](C20_Trabajo.ipynb) | [C20_Soluciones](C20_Soluciones.ipynb) |
| Estado, alias y control de errores en C | [P01_Trabajo](P01_Trabajo.ipynb) | [P01_Soluciones](P01_Soluciones.ipynb) |
| Taller de construcción y herramientas | [C-TALLER_Trabajo](C-TALLER_Trabajo.ipynb) | [C-TALLER_Soluciones](C-TALLER_Soluciones.ipynb) |