#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

enum{MAX_REGISTROS=4};
typedef struct{char nombre[12];int puntos;}Registro;
typedef struct{Registro filas[MAX_REGISTROS];size_t n,rechazos;}Datos;
/* 0: fin sin datos; 1: linea valida; 2: larga o NUL; -1: error. */
int linea(FILE*f,char*b,size_t cap){
    if(cap<2)return -1;
    size_t n=0;int c;bool visto=false,invalida=false;
    while((c=fgetc(f))!=EOF){
        visto=true;if(c=='\n')break;
        if(c==0)invalida=true;
        if(n+1<cap)b[n++]=(char)c;else invalida=true;
    }
    b[n]='\0';if(ferror(f))return -1;
    if(!visto&&c==EOF)return 0;
    return invalida?2:1;
}
bool interpretar(const char*s,Registro*r){
    const char*coma=strchr(s,',');
    if(coma==NULL||strchr(coma+1,',')!=NULL)return false;
    size_t n=(size_t)(coma-s);if(n==0||n>=sizeof r->nombre)return false;
    for(size_t i=0;i<n;++i)
        if(!((s[i]>='A'&&s[i]<='Z')||(s[i]>='a'&&s[i]<='z')))return false;
    const char*p=coma+1;if(*p<'0'||*p>'9')return false;
    errno=0;char*fin=NULL;long valor=strtol(p,&fin,10);
    if(errno==ERANGE||*fin!='\0'||valor<0||valor>100)return false;
    Registro temporal={{0},0};memcpy(temporal.nombre,s,n);temporal.puntos=(int)valor;
    *r=temporal;return true;
}
bool consultar(const Datos*d,const char*nombre,Registro*r){
    for(size_t i=0;i<d->n;++i)if(strcmp(d->filas[i].nombre,nombre)==0){*r=d->filas[i];return true;}
    return false;
}
bool cargar(FILE*f,Datos*d){
    *d=(Datos){{{{0},0}},0,0};char b[64];
    if(linea(f,b,sizeof b)!=1||strcmp(b,"nombre,puntos")!=0)return false;
    int estado;
    while((estado=linea(f,b,sizeof b))!=0){
        if(estado<0)return false;
        Registro r,anterior;
        if(estado!=1||!interpretar(b,&r)||consultar(d,r.nombre,&anterior)||d->n==MAX_REGISTROS){++d->rechazos;continue;}
        d->filas[d->n++]=r;
    }
    return true;
}
FILE* entrada(void){
    FILE*f=tmpfile();if(f==NULL)return NULL;
    const char*s="nombre,puntos\nAzul,8\nRojo,12x\nVerde,10\nNombreDemasiadoLargo,4\nAzul,9\nNegativo,-2\n";
    if(fputs(s,f)==EOF||fflush(f)==EOF){fclose(f);return NULL;}
    rewind(f);return f;
}
bool guardar_csv(const char*ruta,const Datos*d){
    FILE*f=fopen(ruta,"w");if(f==NULL)return false;
    bool ok=fputs("nombre,puntos\n",f)!=EOF;
    for(size_t i=0;i<d->n;++i)
        if(fprintf(f,"%s,%d\n",d->filas[i].nombre,d->filas[i].puntos)<0)ok=false;
    if(fclose(f)!=0)ok=false;
    return ok;
}
bool iguales(const Datos*a,const Datos*b){
    if(a->n!=b->n)return false;
    for(size_t i=0;i<a->n;++i)
        if(strcmp(a->filas[i].nombre,b->filas[i].nombre)!=0||a->filas[i].puntos!=b->filas[i].puntos)return false;
    return true;
}

int main(void) {
    Registro r;
    if(interpretar("Azul,8",&r))printf("%s:%d\n",r.nombre,r.puntos);
    printf("sufijo=%s\n",interpretar("Rojo,12x",&r)?"admitido":"rechazado");
    return 0;
}
