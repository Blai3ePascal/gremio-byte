#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

enum { LIMITE = 8 };
typedef struct { int *datos; size_t longitud, capacidad; } Vector;
bool reservar(Vector *v, size_t nueva) {
    if (nueva <= v->capacidad) return true;
    if (nueva > LIMITE || nueva > SIZE_MAX / sizeof *v->datos) return false;
    int *temporal = v->datos == NULL ? malloc(nueva * sizeof *v->datos) : realloc(v->datos, nueva * sizeof *v->datos);
    if (temporal == NULL) return false;
    v->datos = temporal;
    v->capacidad = nueva;
    return true;
}
bool agregar(Vector *v, int valor) {
    if (v->longitud == v->capacidad) {
        size_t nueva = v->capacidad == 0 ? 2 : v->capacidad * 2;
        if (!reservar(v, nueva)) return false;
    }
    v->datos[v->longitud++] = valor;
    return true;
}
bool leer(const Vector *v, size_t i, int *salida) {
    if (salida == NULL || i >= v->longitud) return false;
    *salida = v->datos[i];
    return true;
}
void invertir(Vector *v) {
    for (size_t i = 0; i < v->longitud / 2; ++i) {
        size_t j = v->longitud - 1 - i;
        int temporal = v->datos[i]; v->datos[i] = v->datos[j]; v->datos[j] = temporal;
    }
}
void mostrar(const Vector *v) {
    for (size_t i = 0; i < v->longitud; ++i)
        printf("%s%d", i ? " " : "", v->datos[i]);
    putchar('\n');
}
void liberar(Vector *v) {
    free(v->datos); v->datos = NULL; v->longitud = 0; v->capacidad = 0;
}

int main(void) {
    Vector v = {NULL, 0, 0};
    for (int x = 1; x <= 4; ++x) if (!agregar(&v, x)) { liberar(&v); return 1; }
    invertir(&v); mostrar(&v);
    Vector vacio = {NULL, 0, 0}; invertir(&vacio);
    printf("vacio=%zu\n", vacio.longitud); liberar(&v);
    return 0;
}
