#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

typedef struct Nodo{int valor;struct Nodo*siguiente;}Nodo;
bool inicio(Nodo**cabeza,int x){
    Nodo*n=malloc(sizeof*n);if(n==NULL)return false;
    n->valor=x;n->siguiente=*cabeza;*cabeza=n;return true;
}
bool final(Nodo**cabeza,int x){
    Nodo*n=malloc(sizeof*n);if(n==NULL)return false;
    n->valor=x;n->siguiente=NULL;
    Nodo**enlace=cabeza;while(*enlace!=NULL)enlace=&(*enlace)->siguiente;
    *enlace=n;return true;
}
bool borrar(Nodo**cabeza,int x){
    Nodo**enlace=cabeza;
    while(*enlace!=NULL&&(*enlace)->valor!=x)enlace=&(*enlace)->siguiente;
    if(*enlace==NULL)return false;
    Nodo*viejo=*enlace;*enlace=viejo->siguiente;free(viejo);return true;
}
void lista(const Nodo*p){
    if(p==NULL){puts("(vacia)");return;}
    bool primero=true;
    while(p!=NULL){printf("%s%d",primero?"":" ",p->valor);primero=false;p=p->siguiente;}
    putchar('\n');
}
void destruir(Nodo**cabeza){
    while(*cabeza!=NULL){Nodo*viejo=*cabeza;*cabeza=viejo->siguiente;free(viejo);}
}

int main(void) {
    Nodo*cabeza=NULL;
    if(!final(&cabeza,4)||!final(&cabeza,7)){destruir(&cabeza);return 1;}
    destruir(&cabeza);printf("cabeza_nula=%s\n",cabeza==NULL?"si":"no");
    destruir(&cabeza);lista(cabeza);
    return 0;
}
