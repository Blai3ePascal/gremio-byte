#include <stdio.h>

int main(void) {
    int matriz[2][3] = {{1, 2, 3}, {4, 5, 6}};
    printf("%d\n", matriz[1][2]);
    printf("%d\n", matriz[0][1]);
    return 0;
}
