int visitar(int filas,int columnas) {
    int total=0;
    for(int f=0;f<filas;f++){
        for(int c=0;c<columnas;c++){total++;}
    }
    return total;
}
