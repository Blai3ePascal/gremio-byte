#include <stdio.h>

int main(void) {
    int datos[] = {4, 7, 2, 5};
    int total = 0;
    for (int i = 0; i < 4; i++) {
        total += datos[i];
    }
    printf("%d\n", total);
    return 0;
}
