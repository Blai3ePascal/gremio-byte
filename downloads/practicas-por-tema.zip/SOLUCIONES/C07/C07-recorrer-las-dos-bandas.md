Visita cada combinación de fila y columna mediante dos bucles anidados. Devuelve cuántas celdas has visitado. Una multiplicación da el número, pero esta misión practica el recorrido con dos bucles.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Campo rectangular | `2 3` | `6` |
| Sin filas | `0 4` | `0` |
| Otro tamaño | `3 5` | `15` |

Visita cada combinación de fila y columna mediante dos bucles anidados. Devuelve cuántas celdas has visitado. Una multiplicación da el número, pero esta misión practica el recorrido con dos bucles.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Campo rectangular | `2 3` | `6` |
| Sin filas | `0 4` | `0` |
| Otro tamaño | `3 5` | `15` |


### Leer la propuesta

- `int visitar(int filas,int columnas) {`: La cabecera define el nombre y los parámetros que recibirá la función.
- `int total=0;`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `for(int f=0;f<filas;f++){`: El bucle recorre un conjunto de valores. Su cuerpo cambia el estado en cada iteración; un segundo bucle recorre combinaciones.
- `for(int c=0;c<columnas;c++){total++;}`: El bucle recorre un conjunto de valores. Su cuerpo cambia el estado en cada iteración; un segundo bucle recorre combinaciones.
- `return total;`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Laboratorio libre cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.