### El encargo

El almacén organiza sus datos por posiciones. Respeta los límites al consultarlos.

Visita cada combinación de fila y columna mediante dos bucles anidados. Devuelve cuántas celdas has visitado. Una multiplicación da el número, pero esta misión practica el recorrido con dos bucles.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Campo rectangular | `2 3` | `6` |
| Sin filas | `0 4` | `0` |
| Otro tamaño | `3 5` | `15` |

### Requisitos de aprendizaje

- Usar dos bucles anidados dentro de la función; ambos deben participar en el cálculo.

### Contrato de la función

Conserva la firma proporcionada. El juego enlaza un programa de prueba que llama a tu función. Devuelve o modifica los datos según el encargo; no sustituyas ese efecto por un mensaje.

- {"stdin": "2 3", "expected": "6\n", "label": "Campo rectangular"}
- {"stdin": "0 4", "expected": "0\n", "label": "Sin filas"}
- {"stdin": "3 5", "expected": "15\n", "label": "Otro tamaño"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Visita cada combinación de fila y columna mediante dos bucles anidados. Devuelve cuántas celdas has visitado. Una multiplicación da el número, pero esta misión practica el recorrido con dos bucles.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Campo rectangular | `2 3` | `6` |
| Sin filas | `0 4` | `0` |
| Otro tamaño | `3 5` | `15` |


### Leer la propuesta

- `int visitar(int filas,int columnas) {`: La cabecera define el nombre y los parámetros que recibirá la función.
- `int total=0;`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `for(int f=0;f<filas;f++){`: El bucle recorre un conjunto de valores. Su cuerpo cambia el estado en cada iteración; un segundo bucle recorre combinaciones.
- `for(int c=0;c<columnas;c++){total++;}`: El bucle recorre un conjunto de valores. Su cuerpo cambia el estado en cada iteración; un segundo bucle recorre combinaciones.
- `return total;`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.