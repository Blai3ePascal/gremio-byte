#include <stdio.h>

int main(void) {
    FILE *f = fopen("puntos.txt", "w");
    if (f == NULL)
        return 1;
    int escrito = fprintf(f, "%d\n", 8);
    int cerrado = fclose(f);
    if (escrito < 0 || cerrado != 0)
        return 1;
    printf("Guardado: 8\n");
    return 0;
}
