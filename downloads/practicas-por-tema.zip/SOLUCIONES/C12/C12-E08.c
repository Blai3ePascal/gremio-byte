#include <stdio.h>

int main(void) {
    FILE *f = tmpfile();
    if (f == NULL)
        return 1;
    if (fputs("azul\nverde\nrojo\n", f) == EOF) {
        fclose(f);
        return 1;
    }
    rewind(f);
    char linea[32];
    int total = 0;
    while (fgets(linea, sizeof linea, f) != NULL)
        total++;
    int error = ferror(f);
    int cerrado = fclose(f);
    if (error || cerrado != 0)
        return 1;
    printf("%d\n", total);
    return 0;
}
