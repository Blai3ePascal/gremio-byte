#include <stdio.h>

int main(void) {
    int datos[] = {7, 9, 11};
    FILE *f = fopen("puntos.bin", "wb");
    if (f == NULL)
        return 1;
    size_t escritos = fwrite(datos, sizeof datos[0], 3, f);
    int cerrado = fclose(f);
    if (escritos != 3 || cerrado != 0)
        return 1;
    printf("Elementos: %zu\n", escritos);
    return 0;
}
