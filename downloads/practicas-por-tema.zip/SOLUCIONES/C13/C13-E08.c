#include <stdio.h>

int main(void) {
    FILE *f = tmpfile();
    if (f == NULL) return 1;
    int origen = 13, destino[2] = {0, 0};
    if (fwrite(&origen, sizeof origen, 1, f) != 1) { fclose(f); return 1; }
    rewind(f);
    size_t leidos = fread(destino, sizeof destino[0], 2, f);
    int error = ferror(f);
    int cerrado = fclose(f);
    if (error || cerrado != 0) return 1;
    printf("%zu %d %d\n", leidos, destino[0], destino[1]);
    return 0;
}
