#include <stdio.h>
#include <string.h>
int main(void) {
    char a[] = "azul";
    char b[] = "verde";
    printf("%d\n", strcmp(a, b) == 0);
    return 0;
}
