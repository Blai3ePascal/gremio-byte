#include <stdio.h>
#include <string.h>
int main(void) {
    char nombre[8] = "Luna";
    printf("%zu\n", strlen(nombre));
    printf("%zu\n", sizeof nombre);
    return 0;
}
