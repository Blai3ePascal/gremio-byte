Intercambia ambos enteros mediante los punteros recibidos. Conserva el valor inicial que necesitas antes de sobrescribirlo.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Dos dorsales | `2 9` | `9 2` |
| Incluye cero | `0 5` | `5 0` |
| Valores iguales | `4 4` | `4 4` |

Intercambia ambos enteros mediante los punteros recibidos. Conserva el valor inicial que necesitas antes de sobrescribirlo.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Dos dorsales | `2 9` | `9 2` |
| Incluye cero | `0 5` | `5 0` |
| Valores iguales | `4 4` | `4 4` |


### Leer la propuesta

- `void cambiar(int *a,int *b) {`: La cabecera define el nombre y los parámetros que recibirá la función.
- `int temporal=*a;`: El asterisco permite acceder al destino del puntero. La función modifica el objeto del llamador.
- `*a=*b;`: El asterisco permite acceder al destino del puntero. La función modifica el objeto del llamador.
- `*b=temporal;`: El asterisco permite acceder al destino del puntero. La función modifica el objeto del llamador.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.