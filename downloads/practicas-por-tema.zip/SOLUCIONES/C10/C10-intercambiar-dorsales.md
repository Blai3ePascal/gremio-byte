### El encargo

Dos talleres comparten datos mediante funciones. Decide qué se modifica y qué se conserva.

Intercambia ambos enteros mediante los punteros recibidos. Conserva el valor inicial que necesitas antes de sobrescribirlo.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Dos dorsales | `2 9` | `9 2` |
| Incluye cero | `0 5` | `5 0` |
| Valores iguales | `4 4` | `4 4` |

### Requisitos de aprendizaje

- Acceder al objeto a través de un puntero o parámetro de array; declararlo sin utilizarlo no basta.

### Contrato de la función

Conserva la firma proporcionada. El juego enlaza un programa de prueba que llama a tu función. Devuelve o modifica los datos según el encargo; no sustituyas ese efecto por un mensaje.

- {"stdin": "2 9", "expected": "9 2\n", "label": "Dos dorsales"}
- {"stdin": "0 5", "expected": "5 0\n", "label": "Incluye cero"}
- {"stdin": "4 4", "expected": "4 4\n", "label": "Valores iguales"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Intercambia ambos enteros mediante los punteros recibidos. Conserva el valor inicial que necesitas antes de sobrescribirlo.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Dos dorsales | `2 9` | `9 2` |
| Incluye cero | `0 5` | `5 0` |
| Valores iguales | `4 4` | `4 4` |


### Leer la propuesta

- `void cambiar(int *a,int *b) {`: La cabecera define el nombre y los parámetros que recibirá la función.
- `int temporal=*a;`: El asterisco permite acceder al destino del puntero. La función modifica el objeto del llamador.
- `*a=*b;`: El asterisco permite acceder al destino del puntero. La función modifica el objeto del llamador.
- `*b=temporal;`: El asterisco permite acceder al destino del puntero. La función modifica el objeto del llamador.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.