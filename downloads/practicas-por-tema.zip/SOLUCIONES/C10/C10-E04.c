#include <stdio.h>
void cambiar(int *a, int *b) {
    int temporal = *a;
    *a = *b;
    *b = temporal;
}
int main(void) {
    int x = -3, y = 4;
    cambiar(&x, &y);
    printf("%d %d\n", x, y);
    return 0;
}
