void cambiar(int *a,int *b) {
    int temporal=*a;
    *a=*b;
    *b=temporal;
}
