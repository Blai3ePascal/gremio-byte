#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>

typedef struct { char nombre[12]; int puntos; } Equipo;
bool iniciar(Equipo *e, int puntos) {
    if (e == NULL || puntos < 0 || puntos > 100) return false;
    e->puntos = puntos;
    return true;
}
int main(void) {
    Equipo azul = {"Azul", 7};
    printf("aceptado=%d\n", iniciar(&azul, 9));
    printf("%s:%d\n", azul.nombre, azul.puntos);
    printf("rechazado=%d\n", !iniciar(&azul, 101));
    printf("conservado=%d\n", azul.puntos);
    return 0;
}
