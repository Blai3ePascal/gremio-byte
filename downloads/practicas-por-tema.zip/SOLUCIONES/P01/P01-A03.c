#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>

typedef struct { char nombre[12]; int puntos; } Equipo;
typedef enum { EQUIPO_OK, EQUIPO_DESTINO, EQUIPO_RANGO } Estado;
Estado iniciar(Equipo *e, int puntos) {
    if (e == NULL) return EQUIPO_DESTINO;
    if (puntos < 0 || puntos > 100) return EQUIPO_RANGO;
    e->puntos = puntos;
    return EQUIPO_OK;
}
int main(void) {
    Equipo azul = {"Azul", 7};
    Estado r = iniciar(&azul, -1);
    printf("rechazo_rango=%d puntos=%d\n", r == EQUIPO_RANGO, azul.puntos);
    r = iniciar(NULL, 4);
    printf("rechazo_destino=%d\n", r == EQUIPO_DESTINO);
    r = iniciar(&azul, 100);
    printf("aceptado=%d puntos=%d\n", r == EQUIPO_OK, azul.puntos);
    return 0;
}
