#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>

typedef struct { char nombre[12]; int puntos; } Equipo;
int main(void) {
    Equipo azul = {"Azul", 3};
    Equipo *alias = &azul;
    Equipo copia = azul;
    alias->puntos += 2;
    copia.puntos += 10;
    printf("original=%d alias=%d copia=%d\n", azul.puntos, alias->puntos, copia.puntos);
    return 0;
}
