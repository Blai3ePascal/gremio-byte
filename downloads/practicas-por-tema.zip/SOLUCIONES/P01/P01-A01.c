#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>

typedef struct { char nombre[12]; int puntos; } Equipo;
bool iniciar(Equipo *e, int puntos) {
    if (e == NULL || puntos < 0 || puntos > 100) return false;
    e->puntos = puntos;
    return true;
}
bool sumar(Equipo *e, int cantidad) {
    if (e == NULL || cantidad < 0 || cantidad > 100 - e->puntos) return false;
    e->puntos += cantidad;
    return true;
}
int main(void) {
    Equipo azul = {"Azul", 0};
    if (!iniciar(&azul, 3) || !sumar(&azul, 2)) return 1;
    printf("%s:%d\n", azul.nombre, azul.puntos);
    return 0;
}
