#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include <ctype.h>

typedef struct { char nombre[12]; int puntos; } Equipo;
bool convertir_nota(const char *texto, int *salida) {
    char *fin;
    long valor;
    if (texto == NULL || salida == NULL) return false;
    errno = 0;
    valor = strtol(texto, &fin, 10);
    if (fin == texto || errno == ERANGE) return false;
    while (isspace((unsigned char)*fin)) ++fin;
    if (*fin != '\0' || valor < 0 || valor > 10) return false;
    *salida = (int)valor;
    return true;
}
int main(void) {
    const char *entradas[] = {"x", "12", "8", " 0 ", "10", "8x", ""};
    size_t i;
    for (i = 0; i < sizeof entradas / sizeof entradas[0]; ++i) {
        int nota = 99;
        bool ok = convertir_nota(entradas[i], &nota);
        printf("[%s] aceptado=%d valor=%d\n", entradas[i], ok, nota);
    }
    return 0;
}
