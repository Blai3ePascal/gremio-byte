#include <stdio.h>

int main(void) {
    unsigned int a = 6, b = 3;
    printf("%u\n", a & b);
    printf("%d\n", a && b);
    printf("%u\n", a | b);
    return 0;
}
