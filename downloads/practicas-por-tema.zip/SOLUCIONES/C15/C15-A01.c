#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

void imprimir(const int a[], size_t n) {
    for (size_t i=0;i<n;++i) { printf("%s%d", i?" ":"",a[i]); }
    putchar('\n');
}
bool lineal(const int a[], size_t n, int x, size_t *pos, size_t *visitas) {
    *visitas=0;
    for(size_t i=0;i<n;++i){ ++*visitas; if(a[i]==x){*pos=i;return true;} }
    return false;
}
bool ordenado(const int a[],size_t n) {
    for(size_t i=1;i<n;++i) if(a[i-1]>a[i]) return false;
    return true;
}
int binaria(const int a[],size_t n,int x,size_t *pos,size_t *visitas) {
    *visitas=0;
    if(!ordenado(a,n)) return -1;
    size_t izq=0,der=n;
    while(izq<der){
        size_t medio=izq+(der-izq)/2; ++*visitas;
        if(a[medio]==x){*pos=medio;return 1;}
        if(a[medio]<x) izq=medio+1; else der=medio;
    }
    return 0;
}
size_t seleccion(int a[],size_t n) {
    size_t comparaciones=0;
    for(size_t i=0;i<n;++i){
        size_t minimo=i;
        for(size_t j=i+1;j<n;++j){++comparaciones;if(a[j]<a[minimo])minimo=j;}
        int tmp=a[i];a[i]=a[minimo];a[minimo]=tmp;
    }
    return comparaciones;
}
size_t insercion(int a[],size_t n) {
    size_t comparaciones=0;
    for(size_t i=1;i<n;++i){
        int clave=a[i];size_t j=i;
        while(j>0){ ++comparaciones; if(a[j-1]<=clave)break; a[j]=a[j-1];--j; }
        a[j]=clave;
    }
    return comparaciones;
}

int main(void) {
    int a[]={9,2,7};size_t p=0,v=0;
    if(lineal(a,3,7,&p,&v))printf("encontrado=%zu visitas=%zu\n",p,v);
    if(!lineal(a,3,6,&p,&v))printf("ausente visitas=%zu\n",v);
    if(!lineal(a,0,7,&p,&v))printf("vacio visitas=%zu\n",v);
    return 0;
}
