#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

enum{MAX_NODOS=8};
typedef struct ArbolNodo{int clave;struct ArbolNodo*izq,*der;}ArbolNodo;
typedef struct{ArbolNodo*raiz;size_t n,limite;}Arbol;
bool contiene(const Arbol*a,int clave){
    const ArbolNodo*p=a->raiz;
    while(p!=NULL){if(clave==p->clave)return true;p=clave<p->clave?p->izq:p->der;}
    return false;
}
bool insertar(Arbol*a,int clave){
    if(contiene(a,clave)||a->n>=a->limite||a->limite>MAX_NODOS)return false;
    ArbolNodo**enlace=&a->raiz;
    while(*enlace!=NULL)enlace=clave<(*enlace)->clave?&(*enlace)->izq:&(*enlace)->der;
    ArbolNodo*n=malloc(sizeof*n);if(n==NULL)return false;
    n->clave=clave;n->izq=NULL;n->der=NULL;*enlace=n;++a->n;return true;
}
void inorden(const ArbolNodo*p){
    if(p==NULL)return;
    inorden(p->izq);printf("%d ",p->clave);inorden(p->der);
}
void liberar_nodos(ArbolNodo*p){
    if(p==NULL)return;
    liberar_nodos(p->izq);liberar_nodos(p->der);free(p);
}
void cerrar_arbol(Arbol*a){liberar_nodos(a->raiz);a->raiz=NULL;a->n=0;}

int main(void) {
    Arbol a={NULL,0,3};
    for(int x=1;x<=3;++x)if(!insertar(&a,x)){cerrar_arbol(&a);return 1;}
    if(!insertar(&a,2))puts("duplicado rechazado");
    if(!insertar(&a,4))puts("limite rechazado");
    printf("n=%zu\n",a.n);cerrar_arbol(&a);
    printf("vacio=%s n=%zu\n",a.raiz==NULL?"si":"no",a.n);
    return 0;
}
