#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

enum{MAX_NODOS=8};
typedef struct ArbolNodo{int clave;struct ArbolNodo*izq,*der;}ArbolNodo;
typedef struct{ArbolNodo*raiz;size_t n,limite;}Arbol;
bool contiene(const Arbol*a,int clave){
    const ArbolNodo*p=a->raiz;
    while(p!=NULL){if(clave==p->clave)return true;p=clave<p->clave?p->izq:p->der;}
    return false;
}
bool insertar(Arbol*a,int clave){
    if(contiene(a,clave)||a->n>=a->limite||a->limite>MAX_NODOS)return false;
    ArbolNodo**enlace=&a->raiz;
    while(*enlace!=NULL)enlace=clave<(*enlace)->clave?&(*enlace)->izq:&(*enlace)->der;
    ArbolNodo*n=malloc(sizeof*n);if(n==NULL)return false;
    n->clave=clave;n->izq=NULL;n->der=NULL;*enlace=n;++a->n;return true;
}
void inorden(const ArbolNodo*p){
    if(p==NULL)return;
    inorden(p->izq);printf("%d ",p->clave);inorden(p->der);
}
void liberar_nodos(ArbolNodo*p){
    if(p==NULL)return;
    liberar_nodos(p->izq);liberar_nodos(p->der);free(p);
}
void cerrar_arbol(Arbol*a){liberar_nodos(a->raiz);a->raiz=NULL;a->n=0;}

int main(void) {
    Arbol a={NULL,0,8};int claves[]={4,2,6,1,3};
    for(size_t i=0;i<5;++i)if(!insertar(&a,claves[i])){cerrar_arbol(&a);return 1;}
    inorden(a.raiz);putchar('\n');
    printf("buscar3=%s buscar5=%s\n",contiene(&a,3)?"si":"no",contiene(&a,5)?"si":"no");cerrar_arbol(&a);
    return 0;
}
