#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

enum{CAP=3};
typedef struct{int datos[CAP];size_t n;} Pila;
bool push(Pila*p,int x){if(p->n==CAP)return false;p->datos[p->n++]=x;return true;}
bool pop(Pila*p,int*out){if(out==NULL||p->n==0)return false;*out=p->datos[--p->n];return true;}
typedef struct{int datos[CAP];size_t cabeza,n;} Cola;
bool encolar(Cola*q,int x){if(q->n==CAP)return false;size_t i=(q->cabeza+q->n)%CAP;q->datos[i]=x;++q->n;return true;}
bool desencolar(Cola*q,int*out){if(out==NULL||q->n==0)return false;*out=q->datos[q->cabeza];q->cabeza=(q->cabeza+1)%CAP;--q->n;return true;}

int main(void) {
    Cola q={{0},0,0};int x=0;
    if(!encolar(&q,2)||!encolar(&q,5))return 1;
    while(desencolar(&q,&x))printf("sale=%d\n",x);
    printf("restantes=%zu\n",q.n);
    return 0;
}
