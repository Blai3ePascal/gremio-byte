#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <limits.h>

enum{MAX_TABLA=16};
typedef struct{int clave;bool ocupada;}Celda;
typedef struct{Celda*celdas;size_t capacidad,n;}Tabla;
bool iniciar(Tabla*t,size_t capacidad){
    if(capacidad==0||capacidad>MAX_TABLA||capacidad>SIZE_MAX/sizeof* t->celdas)return false;
    Celda*p=calloc(capacidad,sizeof*p);if(p==NULL)return false;
    t->celdas=p;t->capacidad=capacidad;t->n=0;return true;
}
int guardar(Tabla*t,int clave){
    if(clave<=0||t->capacidad==0)return -1;
    size_t origen=(size_t)clave%t->capacidad;
    for(size_t paso=0;paso<t->capacidad;++paso){
        size_t i=(origen+paso)%t->capacidad;
        if(t->celdas[i].ocupada){if(t->celdas[i].clave==clave)return 0;}
        else{t->celdas[i].clave=clave;t->celdas[i].ocupada=true;++t->n;return 1;}
    }
    return -2;
}
bool buscar(const Tabla*t,int clave){
    if(clave<=0||t->capacidad==0)return false;
    size_t origen=(size_t)clave%t->capacidad;
    for(size_t paso=0;paso<t->capacidad;++paso){
        size_t i=(origen+paso)%t->capacidad;
        if(!t->celdas[i].ocupada)return false;
        if(t->celdas[i].clave==clave)return true;
    }
    return false;
}
bool crecer(Tabla*t,size_t nueva){
    if(nueva<=t->capacidad||nueva>MAX_TABLA)return false;
    Tabla temporal={NULL,0,0};if(!iniciar(&temporal,nueva))return false;
    for(size_t i=0;i<t->capacidad;++i){
        if(t->celdas[i].ocupada&&guardar(&temporal,t->celdas[i].clave)!=1){free(temporal.celdas);return false;}
    }
    free(t->celdas);*t=temporal;return true;
}
void cerrar_tabla(Tabla*t){free(t->celdas);t->celdas=NULL;t->capacidad=0;t->n=0;}

int main(void) {
    Tabla t={NULL,0,0};if(!iniciar(&t,3))return 1;
    int r1=guardar(&t,1);int r4=guardar(&t,4);
    printf("alta1=%d alta4=%d\n",r1,r4);
    printf("buscar4=%s\n",buscar(&t,4)?"si":"no");cerrar_tabla(&t);
    return 0;
}
