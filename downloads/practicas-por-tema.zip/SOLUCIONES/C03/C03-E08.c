#include <stdio.h>

int main(void) {
    const char *entrada = "abc";
    int edad = 0;
    if (sscanf(entrada, "%d", &edad) != 1) {
        printf("Entrada invalida\n");
        return 1;
    }
    printf("Edad: %d\n", edad);
    return 0;
}
