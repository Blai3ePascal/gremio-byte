#include <stdio.h>

int main(void) {
    int suma = 7, cantidad = 2;
    double media = (double)suma / cantidad;
    printf("%.1f\n", media);
    return 0;
}
