#include <stdio.h>

int main(void) {
    int suma = 11, cantidad = 4;
    double media = (double)suma / cantidad;
    printf("%.2f\n", media);
    return 0;
}
