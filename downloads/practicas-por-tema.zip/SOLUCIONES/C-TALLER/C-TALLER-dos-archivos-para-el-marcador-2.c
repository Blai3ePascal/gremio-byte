#include <stdio.h>
#include "motor.h"
int main(void){printf("%d\n",puntos(2));return 0;}
