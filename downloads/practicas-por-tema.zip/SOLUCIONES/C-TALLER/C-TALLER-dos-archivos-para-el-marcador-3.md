El módulo motor.c define puntos. Completa una llamada desde main.c y conserva la declaración en motor.h. El motor compila realmente ambos .c.

El módulo motor.c define puntos. Completa una llamada desde main.c y conserva la declaración en motor.h. El motor compila realmente ambos .c.

### Leer la propuesta

- `#include <stdio.h>`: La cabecera declara las funciones o el contrato compartido que utiliza este archivo.
- `#include "motor.h"`: La cabecera declara las funciones o el contrato compartido que utiliza este archivo.
- `int main(void){printf("%d\n",puntos(3));return 0;}`: Presenta el resultado para observarlo y compararlo. El salto de línea separa los resultados.

### Prueba otra decisión

En Laboratorio libre cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.