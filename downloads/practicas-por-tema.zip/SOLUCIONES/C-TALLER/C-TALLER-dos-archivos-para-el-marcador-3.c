#include <stdio.h>
#include "motor.h"
int main(void){printf("%d\n",puntos(3));return 0;}
