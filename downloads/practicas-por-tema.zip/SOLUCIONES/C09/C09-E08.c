#include <stdio.h>

int main(void) {
    int a = 2, b = 8;
    int *p = &a;
    *p += 1;
    printf("%d %d\n", a, b);
    return 0;
}
