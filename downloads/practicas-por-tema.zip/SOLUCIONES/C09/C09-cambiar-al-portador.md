Actualiza el entero del llamador sumándole 3 a través de un puntero válido. No basta con cambiar una copia local. Comprueba NULL antes de escribir para conservar el contrato de la función.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Marcador inicial | `0` | `3` |
| Marcador existente | `7` | `10` |
| Otra ficha | `14` | `17` |

Actualiza el entero del llamador sumándole 3 a través de un puntero válido. No basta con cambiar una copia local. Comprueba NULL antes de escribir para conservar el contrato de la función.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Marcador inicial | `0` | `3` |
| Marcador existente | `7` | `10` |
| Otra ficha | `14` | `17` |


### Leer la propuesta

- `void premiar(int *puntos) {`: La cabecera define el nombre y los parámetros que recibirá la función.
- `if(puntos != NULL){*puntos += 3;}`: La condición selecciona la rama. Comprueba qué ocurre con el caso límite antes de entrar en ella.

### Prueba otra decisión

En Laboratorio libre cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.