void premiar(int *puntos) {
    if (puntos != NULL) {
        *puntos += 3;
    }
}
