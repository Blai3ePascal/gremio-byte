#include <stdio.h>

int main(void) {
    int puntos = 7;
    int *p = &puntos;
    *p += 3;
    printf("%d %d\n", puntos, *p);
    return 0;
}
