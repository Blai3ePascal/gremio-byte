#include <stdio.h>

int main(void) {
    int puntos = 0;
    if (scanf("%d", &puntos) != 1) {
        return 1;
    }
    int *p = &puntos;
    *p += 3;
    printf("%d %d\n", puntos, *p);
    return 0;
}
