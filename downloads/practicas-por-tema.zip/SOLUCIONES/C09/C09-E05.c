#include <stdio.h>

int main(void) {
    int a = 2, b = 8;
    int *p = &a;
    p = &b;
    *p = 9;
    printf("%d %d\n", a, b);
    return 0;
}
