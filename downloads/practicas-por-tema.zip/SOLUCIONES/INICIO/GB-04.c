#include <stdio.h>
int main(void) {
    int runas[3] = {2, 5, 8};
    for (int i = 2; i >= 0; i--) printf("%d\n", runas[i]);
    return 0;
}
