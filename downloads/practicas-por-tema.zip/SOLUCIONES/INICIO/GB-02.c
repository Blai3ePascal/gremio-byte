#include <stdio.h>
int main(void) {
    int oro = 7;
    printf("%d\n", oro * 2);
    return 0;
}
