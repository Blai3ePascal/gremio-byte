#include <stdio.h>

int main(void) {
    int opcion = 2;
    switch (opcion) {
        case 1: printf("Crear\n"); break;
        case 2: printf("Listar\n"); break;
        default: printf("Opcion invalida\n");
    }
    return 0;
}
