### El encargo

El taller repite tareas: construye una repetición que avance y termine.

Calcula 1 + 2 + ... + n usando un bucle. n es un entero entre 0 y 100. Un contador avanza y un acumulador conserva el total.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Cero sesiones | `0` | `0` |
| Tres sesiones | `3` | `6` |
| Siete sesiones | `7` | `28` |

### Requisitos de aprendizaje

- Usar un bucle que recorra los datos y termine.

### Contrato de la función

Conserva la firma proporcionada. El juego enlaza un programa de prueba que llama a tu función. Devuelve o modifica los datos según el encargo; no sustituyas ese efecto por un mensaje.

- {"stdin": "0", "expected": "0\n", "label": "Cero sesiones"}
- {"stdin": "3", "expected": "6\n", "label": "Tres sesiones"}
- {"stdin": "7", "expected": "28\n", "label": "Siete sesiones"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Calcula 1 + 2 + ... + n usando un bucle. n es un entero entre 0 y 100. Un contador avanza y un acumulador conserva el total.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Cero sesiones | `0` | `0` |
| Tres sesiones | `3` | `6` |
| Siete sesiones | `7` | `28` |


### Leer la propuesta

- `int entrenar(int n) {`: La cabecera define el nombre y los parámetros que recibirá la función.
- `int total=0;`: Conserva o actualiza este dato antes de la siguiente operación. Puedes consultar cada palabra en el glosario.
- `for(int i=1;i<=n;i++){total+=i;}`: El bucle recorre un conjunto de valores. Su cuerpo cambia el estado en cada iteración; un segundo bucle recorre combinaciones.
- `return total;`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.