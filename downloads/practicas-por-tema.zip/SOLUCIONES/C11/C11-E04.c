#include <stdio.h>
struct Equipo {
    int id;
    int puntos;
};
int main(void) {
    struct Equipo verde = {2, 4};
    verde.puntos += 5;
    printf("%d %d\n", verde.id, verde.puntos);
    return 0;
}
