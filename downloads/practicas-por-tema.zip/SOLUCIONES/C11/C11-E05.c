#include <stdio.h>
struct Equipo {
    int id;
    int puntos;
};
void premiar(struct Equipo *equipo) {
    equipo->puntos += 2;
}
int main(void) {
    struct Equipo azul = {1, 7};
    premiar(&azul);
    printf("%d\n", azul.puntos);
    return 0;
}
