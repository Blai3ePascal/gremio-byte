#include <stdio.h>

int main(void) {
    printf("Equipo verde\n");
    printf("Puntos: %d\n", 4 + 6);
    return 0;
}
