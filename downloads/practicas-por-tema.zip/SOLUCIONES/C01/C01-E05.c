#include <stdio.h>

int main(void) {
    printf("Sala ");
    printf("4\n");
    printf("Lista\n");
    return 0;
}
