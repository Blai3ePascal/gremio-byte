#include <stdio.h>

int main(void) {
    printf("Sala ");
    printf("8\n");
    printf("Abierta\n");
    return 0;
}
