#include <stdio.h>

int main(void) {
    printf("Equipo azul\n");
    printf("Puntos: %d\n", 2 + 3);
    return 0;
}
