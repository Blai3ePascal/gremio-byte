int avanzar(int metros) {
    return metros + 3;
}
