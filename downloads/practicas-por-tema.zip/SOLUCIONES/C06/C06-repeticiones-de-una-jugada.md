Recibe n entre 0 y 20. Devuelve n usando una llamada recursiva que reduzca el problema y un caso base n == 0. Esta misión practica recursión.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Caso base | `0` | `0` |
| Una llamada pendiente | `1` | `1` |
| Seis niveles | `6` | `6` |

Recibe n entre 0 y 20. Devuelve n usando una llamada recursiva que reduzca el problema y un caso base n == 0. Esta misión practica recursión.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Caso base | `0` | `0` |
| Una llamada pendiente | `1` | `1` |
| Seis niveles | `6` | `6` |


### Leer la propuesta

- `int repetir(int n) {`: La cabecera define el nombre y los parámetros que recibirá la función.
- `if(n==0)return 0;`: La condición selecciona la rama. Comprueba qué ocurre con el caso límite antes de entrar en ella.
- `return 1 + repetir(n-1);`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Laboratorio libre cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.