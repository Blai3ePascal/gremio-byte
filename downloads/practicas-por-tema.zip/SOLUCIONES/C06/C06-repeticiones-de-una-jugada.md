### El encargo

El gremio quiere reutilizar sus herramientas: separa cada tarea en una función.

Recibe n entre 0 y 20. Devuelve n usando una llamada recursiva que reduzca el problema y un caso base n == 0. Esta misión practica recursión.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Caso base | `0` | `0` |
| Una llamada pendiente | `1` | `1` |
| Seis niveles | `6` | `6` |

### Requisitos de aprendizaje

- Definir y utilizar una función para el cálculo; conserva la firma si se proporciona.
- Resolver mediante recursión y un caso base.

### Contrato de la función

Conserva la firma proporcionada. El juego enlaza un programa de prueba que llama a tu función. Devuelve o modifica los datos según el encargo; no sustituyas ese efecto por un mensaje.

- {"stdin": "0", "expected": "0\n", "label": "Caso base"}
- {"stdin": "1", "expected": "1\n", "label": "Una llamada pendiente"}
- {"stdin": "6", "expected": "6\n", "label": "Seis niveles"}

### Tu margen de decisión

Puedes cambiar nombres y organizar el código de otra forma, salvo firmas, tablas, archivos o técnicas exigidos arriba. La propuesta del cuaderno es una solución posible. En «Probar cambios» puedes explorar otros datos sin alterar tu borrador ni ganar recompensas.


Recibe n entre 0 y 20. Devuelve n usando una llamada recursiva que reduzca el problema y un caso base n == 0. Esta misión practica recursión.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Caso base | `0` | `0` |
| Una llamada pendiente | `1` | `1` |
| Seis niveles | `6` | `6` |


### Leer la propuesta

- `int repetir(int n) {`: La cabecera define el nombre y los parámetros que recibirá la función.
- `if(n==0)return 0;`: La condición selecciona la rama. Comprueba qué ocurre con el caso límite antes de entrar en ella.
- `return 1 + repetir(n-1);`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.