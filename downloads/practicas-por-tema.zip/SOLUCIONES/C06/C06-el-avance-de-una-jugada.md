Devuelve el avance actual más 3. El motor usa varias entradas y mueve al portador hasta el resultado calculado.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Sin avance previo | `0` | `3` |
| Avance intermedio | `4` | `7` |
| Otra entrada | `12` | `15` |

Devuelve el avance actual más 3. El motor usa varias entradas y mueve al portador hasta el resultado calculado.

### Casos de comprobación

| Caso | Entrada | Resultado |
|---|---|---|
| Sin avance previo | `0` | `3` |
| Avance intermedio | `4` | `7` |
| Otra entrada | `12` | `15` |


### Leer la propuesta

- `int avanzar(int metros) {`: La cabecera define el nombre y los parámetros que recibirá la función.
- `return metros + 3;`: Entrega este valor al código que llamó a la función; no equivale a mostrarlo en pantalla.

### Prueba otra decisión

En Probar cambios cambia un dato o un tamaño y compara la salida. Vuelve al objetivo para comprobar los casos de la misión. Si aparecen dos bucles, identifica qué recorre cada uno; si aparece una dirección, distingue el puntero de su destino.