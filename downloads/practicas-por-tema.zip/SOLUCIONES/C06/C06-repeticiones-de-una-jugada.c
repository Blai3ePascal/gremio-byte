int repetir(int n) {
    if(n==0)return 0;
    return 1 + repetir(n-1);
}
