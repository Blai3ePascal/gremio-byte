#include <stdio.h>
int sumar(int a, int b) {
    return a + b;
}
int main(void) {
    int resultado = sumar(3, 5);
    printf("%d\n", resultado);
    return 0;
}
