# Cuadernos de Pascal & Sara · Edición 1.2

Empieza por INDICE.md. Cada bloque tiene Trabajo y Soluciones. En Colab, sube el .ipynb y sigue Entiende → Predice → Tu código → Comprueba. No ejecutes todas las celdas del cuaderno de trabajo sin completar los huecos.

La teoría y las referencias están plegadas. Los códigos de preparación y ejecución están identificados; edita solo Tu código. Guarda tus predicciones y explicaciones dentro del cuaderno. El cierre de cada tema propone repetir una actividad sin ayuda y explicar su razonamiento al profesorado.

C requiere Linux y GCC; Python/SQL usa Python 3 con numpy, pandas y matplotlib en los bloques correspondientes. La web es la referencia de versión: CPython 3.12, GCC 14.2 en 32 bits y SQLite. Diferencias de versión o arquitectura pueden cambiar representación o tamaños; no son automáticamente errores conceptuales.

Las diapositivas y evaluación oficial se conservan en los paquetes originales.
