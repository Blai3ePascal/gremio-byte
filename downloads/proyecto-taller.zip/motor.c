#include "motor.h"
int puntos(int n){return n*3;}
