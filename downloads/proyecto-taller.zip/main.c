#include <stdio.h>
#include "motor.h"
int main(void){printf("%d\n",puntos(4));return 0;}
