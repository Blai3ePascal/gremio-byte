#ifndef MOTOR_H
#define MOTOR_H
int puntos(int n);
#endif
