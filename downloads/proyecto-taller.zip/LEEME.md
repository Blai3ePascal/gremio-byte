# Taller

Pascal y Sara Ignacio-Cerrato Ph.D.

Compila: gcc -std=c99 -Wall -Wextra -Wpedantic main.c motor.c -o partido
Ejecuta: ./partido (resultado: 12)
Con Make: make; ./partido; make clean
Con CMake: cmake -S . -B build; cmake --build build; ./build/partido
Git: git init; git add main.c motor.c motor.h Makefile CMakeLists.txt .gitignore LEEME.md; git commit -m "Marcador del club"
Modifica el 4 de main.c, consulta git diff, compila y ejecuta otra vez. Un cambio de fuente no modifica un ejecutable que no se recompila.
CLion: abre esta carpeta y selecciona un kit con gcc y CMake disponibles; configura un objetivo C, compila y coloca un punto de ruptura en puntos. Git y CLion no se ejecutan dentro del editor de la web.
